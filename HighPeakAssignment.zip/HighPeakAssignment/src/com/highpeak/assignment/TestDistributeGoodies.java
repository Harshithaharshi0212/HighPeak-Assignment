package com.highpeak.assignment;

public class TestDistributeGoodies {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String goodiesInputFilePath = "goodiesinput_2.txt";
		String goodiesOutputFilePath = "goodiesoutput_2.txt";
		
		String goodiesInputFilePath_1 = "goodiesinput_5.txt";
		String goodiesOutputFilePath_1 = "goodiesoutput_5.txt";
		
		String goodiesInputFilePath_2 = "goodiesinput_6.txt";
		String goodiesOutputFilePath_2 = "goodiesoutput_6.txt";
		
		DistributeGoodies distributeCookies_one = new DistributeGoodies();
		distributeCookies_one.createDistributeGoodiesOutputFile(goodiesInputFilePath,goodiesOutputFilePath);
		
		
		DistributeGoodies distributeCookies_two = new DistributeGoodies();
		distributeCookies_two.createDistributeGoodiesOutputFile(goodiesInputFilePath_1,goodiesOutputFilePath_1);
		
		
		DistributeGoodies distributeCookies_three = new DistributeGoodies();
		distributeCookies_three.createDistributeGoodiesOutputFile(goodiesInputFilePath_2,goodiesOutputFilePath_2);
		
		System.out.println("Output File is generated");
	}

}
