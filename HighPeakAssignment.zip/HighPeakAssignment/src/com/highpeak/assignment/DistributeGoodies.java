package com.highpeak.assignment;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;


public class DistributeGoodies {
	
	
	/**
	 *  Method reads sample goodies input file and prepares list of goodies items 
	 * 
	 * @return ArrayList<Goodies> 
	 */
	public ArrayList<Goodies> readInputFile(String inputFile) {	
		
		ArrayList<Goodies> goodiesList = new ArrayList<Goodies>();
		Scanner sc = null;
		try {
			FileInputStream fis=new FileInputStream(inputFile);       
		    sc=new Scanner(fis);
		    sc.nextLine(); sc.nextLine(); sc.nextLine(); sc.nextLine();
		    while(sc.hasNextLine())  
		    {
		      String current[] = sc.nextLine().split(": ");
		      Goodies goodies = new Goodies();
		      goodies.setName(current[0]);
		      goodies.setPrice(Integer.parseInt(current[1]));
		      goodiesList.add(goodies);
		    }
		}	
		catch(Exception e) {
			e.printStackTrace();
		} finally {
			
			if(sc != null)
				sc.close();
		}	
	    return goodiesList;
		
	}
	/**
	 * Returns employee count  
	 * 
	 * @return ArrayList<Goodies> 
	 */
	public int getEmployeeCount(String inputFile) {
		
		Scanner sc = null;
		int number_of_employees = -1;
		try {
			FileInputStream fis=new FileInputStream(inputFile);       
		    sc=new Scanner(fis);
		    number_of_employees = Integer.parseInt(sc.nextLine().split(": ")[1]);
		}
		catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(sc != null)
				sc.close();
		}	
	    return number_of_employees;
		 
	}
	/**
	 * Creates goodies distribution output file
	 * @param inputFilePath
	 * @param outputFile
	 */
	public void createDistributeGoodiesOutputFile(String inputFilePath,String outputFile) 
	{
		FileWriter fw = null;
		ArrayList<Goodies> goodiesList = readInputFile(inputFilePath);
		int number_of_employees = getEmployeeCount(inputFilePath);
	    Collections.sort(goodiesList, new Comparator<Goodies>(){
	        public int compare(Goodies a, Goodies b) { 
	          return a.getPrice() - b.getPrice(); 
	        } 
	      });

	      int min_diff = goodiesList.get(goodiesList.size()-1).getPrice();
	      int min_index = 0;
	      for(int i=0;i<goodiesList.size()-number_of_employees+1;i++) {
	        int diff = goodiesList.get(number_of_employees+i-1).getPrice()-goodiesList.get(i).getPrice();

	        if(diff<=min_diff) {
	          min_diff = diff;
	          min_index = i;
	        }
	      }     
	      
	      try {
		      fw = new FileWriter(outputFile);
		      fw.write("Here the goodies that are selected for distribution are:\n\n");
		      for(int i=min_index;i<min_index + number_of_employees; i++) {
		        fw.write(goodiesList.get(i).toString() + "\n");
		      }
	
		      fw.write("\nAnd the difference between the chosen goodie with highest price and the lowest price is " + min_diff);
	      }
	      catch(Exception exp) {
	    	  exp.printStackTrace();
	      } finally {
	    	  if(fw != null)
				try {
					fw.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	      }
	}

}
